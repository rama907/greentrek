<?php
date_default_timezone_set('Asia/Jakarta');
echo json_encode(['time' => date('H:i:s')]);
?>
